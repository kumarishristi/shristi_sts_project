package com.cognizant.jpa.jpain10steps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaIn10StepsApplicationTests {

	@Test
	void contextLoads() {
	}

}
